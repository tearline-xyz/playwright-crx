import { G as browserExports } from "./index-CE4WjMXt.mjs";
import { _, Z, X, $, Y, U } from "./index-CE4WjMXt.mjs";
const debug = browserExports.debug;
export {
  debug as _debug,
  _ as _isUnderTest,
  Z as _setUnderTest,
  X as crx,
  $ as default,
  Y as errors,
  U as selectors
};
//# sourceMappingURL=index.mjs.map
