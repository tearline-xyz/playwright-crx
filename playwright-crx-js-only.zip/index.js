"use strict";
Object.defineProperties(exports, { __esModule: { value: true }, [Symbol.toStringTag]: { value: "Module" } });
const index = require("./index-BTSEn_dr.js");
exports._isUnderTest = index.isUnderTest;
exports._setUnderTest = index.setUnderTest;
exports.crx = index.crx;
exports.default = index.playwrightAPI;
exports.errors = index.errors;
exports.selectors = index.selectors;
exports._debug = index.browserExports$1.debug;
//# sourceMappingURL=index.js.map
